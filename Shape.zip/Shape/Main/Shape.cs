﻿abstract class Shape
{
    public string shapeName { get; set; }

    public abstract double findArea();
    public abstract double findPerimeter();
}